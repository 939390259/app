package com.example.stock

import android.content.Context
import android.net.Uri
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import kotlinx.coroutines.tasks.await

data class Suggestion(
    val barcode: String = "",
    val texts: List<String> = emptyList(),   // 包装/标签上的文字(OCR)
    val labels: List<String> = emptyList()   // 通用物体标签(英文)
)

/** 全部在手机本地运行，无需联网。 */
suspend fun recognize(ctx: Context, uri: Uri): Suggestion {
    val img = InputImage.fromFilePath(ctx, uri)
    val code = BarcodeScanning.getClient().process(img).await().firstOrNull()?.rawValue ?: ""
    // 按文字大小排序：包装上最大的字(通常是品名/品牌)排最前
    val texts = TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
        .process(img).await().textBlocks.flatMap { it.lines }
        .sortedByDescending { it.boundingBox?.height() ?: 0 }
        .map { it.text.trim() }.filter { it.length in 2..20 }.distinct().take(10)
    val labels: List<String> = emptyList()   // 通用物体标签(英文)
)

/** 全部在手机本地运行，无需联网。 */
suspend fun recognize(ctx: Context, uri: Uri): Suggestion {
    val img = InputImage.fromFilePath(ctx, uri)
    val code = BarcodeScanning.getClient().process(img).await().firstOrNull()?.rawValue ?: ""
    val texts = TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
        .process(img).await().textBlocks
        .map { it.text.replace("\n", " ").trim() }.filter { it.length in 2..30 }.take(8)
    val labels = ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS)
        .process(img).await().filter { it.confidence > 0.5f }.take(4).map { it.text }
    return Suggestion(code, texts, labels)
}
