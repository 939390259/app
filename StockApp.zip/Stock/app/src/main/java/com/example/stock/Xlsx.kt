package com.example.stock

import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayInputStream
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

class Formula(val f: String)

/** 不依赖第三方库的最小 xlsx 读写：读第一个工作表；写单工作表(首行加粗、冻结)。 */
object Xlsx {
    fun read(ins: InputStream): List<List<String>> {
        val files = HashMap<String, ByteArray>()
        ZipInputStream(ins).use { z ->
            var e = z.nextEntry
            while (e != null) {
                val n = e.name
                if (n == "xl/sharedStrings.xml" || (n.startsWith("xl/worksheets/sheet") && n.endsWith(".xml"))) files[n] = z.readBytes()
                e = z.nextEntry
            }
        }
        val sheetName = files.keys.filter { it.startsWith("xl/worksheets/") }.sorted().firstOrNull() ?: return emptyList()
        val sst = files["xl/sharedStrings.xml"]?.let { shared(it) } ?: emptyList()
        return sheet(files[sheetName]!!, sst)
    }

    private fun shared(b: ByteArray): List<String> {
        val out = ArrayList<String>()
        val p = Xml.newPullParser(); p.setInput(ByteArrayInputStream(b), null)
        var sb = StringBuilder(); var inSi = false; var inPh = false
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG) {
                when (p.name) {
                    "si" -> { sb = StringBuilder(); inSi = true }
                    "rPh" -> inPh = true
                    "t" -> if (inSi && !inPh) sb.append(p.nextText())
                }
            } else if (ev == XmlPullParser.END_TAG) {
                when (p.name) {
                    "si" -> { out.add(sb.toString()); inSi = false }
                    "rPh" -> inPh = false
                }
            }
            ev = p.next()
        }
        return out
    }

    private fun colIdx(ref: String): Int {
        var n = 0
        for (ch in ref) { if (ch in 'A'..'Z') n = n * 26 + (ch - 'A' + 1) else break }
        return n - 1
    }

    private fun sheet(b: ByteArray, sst: List<String>): List<List<String>> {
        val rows = ArrayList<List<String>>()
        val p = Xml.newPullParser(); p.setInput(ByteArrayInputStream(b), null)
        var row: HashMap<Int, String>? = null
        var col = 0; var next = 0; var type = ""; var v = ""; val inl = StringBuilder()
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG) {
                when (p.name) {
                    "row" -> { row = HashMap(); next = 0 }
                    "c" -> {
                        val ref = p.getAttributeValue(null, "r")
                        col = if (ref != null) colIdx(ref) else next
                        next = col + 1
                        type = p.getAttributeValue(null, "t") ?: ""
                        v = ""; inl.setLength(0)
                    }
                    "v" -> v = p.nextText()
                    "t" -> if (type == "inlineStr") inl.append(p.nextText())
                }
            } else if (ev == XmlPullParser.END_TAG) {
                when (p.name) {
                    "c" -> {
                        val s = when (type) {
                            "s" -> sst.getOrNull(v.toIntOrNull() ?: -1) ?: ""
                            "inlineStr" -> inl.toString()
                            else -> v
                        }
                        row?.put(col, s)
                    }
                    "row" -> {
                        val r = row
                        if (r != null) { val mx = r.keys.maxOrNull() ?: -1; rows.add(List(mx + 1) { r[it] ?: "" }) }
                        row = null
                    }
                }
            }
            ev = p.next()
        }
        return rows
    }

    private fun colName(i: Int): String {
        var n = i; val sb = StringBuilder()
        do { sb.insert(0, 'A' + n % 26); n = n / 26 - 1 } while (n >= 0)
        return sb.toString()
    }

    private fun esc(s: String) = buildString {
        for (c in s) when {
            c == '&' -> append("&amp;"); c == '<' -> append("&lt;"); c == '>' -> append("&gt;")
            c.code < 32 && c != '\n' && c != '\t' -> {}
            else -> append(c)
        }
    }

    fun write(out: OutputStream, rows: List<List<Any?>>, widths: List<Int>) {
        val ns = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
        val sd = StringBuilder()
        rows.forEachIndexed { r, row ->
            sd.append("<row r=\"${r + 1}\">")
            row.forEachIndexed { c, v ->
                val ref = "${colName(c)}${r + 1}"
                val s = if (r == 0) " s=\"1\"" else ""
                when (v) {
                    null -> {}
                    is Formula -> sd.append("<c r=\"$ref\"$s><f>${esc(v.f)}</f></c>")
                    is Number -> sd.append("<c r=\"$ref\"$s><v>$v</v></c>")
                    else -> { val t = v.toString(); if (t.isNotEmpty()) sd.append("<c r=\"$ref\"$s t=\"inlineStr\"><is><t xml:space=\"preserve\">${esc(t)}</t></is></c>") }
                }
            }
            sd.append("</row>")
        }
        val cols = widths.mapIndexed { i, w -> "<col min=\"${i + 1}\" max=\"${i + 1}\" width=\"$w\" customWidth=\"1\"/>" }.joinToString("")
        val sheet = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><worksheet xmlns=\"$ns\"><sheetViews><sheetView workbookViewId=\"0\"><pane ySplit=\"1\" topLeftCell=\"A2\" activePane=\"bottomLeft\" state=\"frozen\"/></sheetView></sheetViews><cols>$cols</cols><sheetData>$sd</sheetData></worksheet>"
        val rel = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
        ZipOutputStream(out).use { z ->
            fun put(name: String, s: String) { z.putNextEntry(ZipEntry(name)); z.write(s.toByteArray(Charsets.UTF_8)); z.closeEntry() }
            val h = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
            put("[Content_Types].xml", "$h<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/><Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/><Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/></Types>")
            put("_rels/.rels", "$h<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"$rel/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>")
            put("xl/workbook.xml", "$h<workbook xmlns=\"$ns\" xmlns:r=\"$rel\"><sheets><sheet name=\"库存\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>")
            put("xl/_rels/workbook.xml.rels", "$h<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"$rel/worksheet\" Target=\"worksheets/sheet1.xml\"/><Relationship Id=\"rId2\" Type=\"$rel/styles\" Target=\"styles.xml\"/></Relationships>")
            put("xl/styles.xml", "$h<styleSheet xmlns=\"$ns\"><fonts count=\"2\"><font><sz val=\"11\"/><name val=\"Arial\"/></font><font><b/><sz val=\"11\"/><name val=\"Arial\"/></font></fonts><fills count=\"2\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill></fills><borders count=\"1\"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs><cellXfs count=\"2\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/><xf numFmtId=\"0\" fontId=\"1\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyFont=\"1\"/></cellXfs></styleSheet>")
            put("xl/worksheets/sheet1.xml", sheet)
        }
    }
}
