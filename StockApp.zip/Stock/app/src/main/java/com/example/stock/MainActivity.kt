@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, kotlinx.coroutines.ExperimentalCoroutinesApi::class)
package com.example.stock

import android.app.Application
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.room.Room
import coil.compose.AsyncImage
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.File

class VM(app: Application) : AndroidViewModel(app) {
    val dao = Room.databaseBuilder(app, AppDb::class.java, "stock.db").build().dao()
    val query = MutableStateFlow("")
    val items = query.flatMapLatest { dao.search(it) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    fun save(i: Item) = viewModelScope.launch { dao.upsert(i) }
    fun delete(i: Item) = viewModelScope.launch { dao.delete(i) }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { App() } }
    }
}

@Composable
fun App(vm: VM = viewModel()) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val list by vm.items.collectAsState()
    val q by vm.query.collectAsState()
    var editing by remember { mutableStateOf<Item?>(null) }
    var sug by remember { mutableStateOf(Suggestion()) }
    var pending by remember { mutableStateOf<File?>(null) }

    val cam = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val f = pending ?: return@rememberLauncherForActivityResult
        if (!ok) { f.delete(); return@rememberLauncherForActivityResult }
        scope.launch {
            val s = runCatching { recognize(ctx, Uri.fromFile(f)) }.getOrDefault(Suggestion())
            val dup = if (s.barcode.isNotEmpty()) vm.dao.byBarcode(s.barcode) else null
            sug = s
            // 条码已存在 -> 打开原物料并数量+1；否则新建草稿
            editing = dup?.copy(quantity = dup.quantity + 1)
                ?: Item(name = "", category = "", quantity = 1, barcode = s.barcode, note = "", photoPath = f.absolutePath)
        }
    }

    val e = editing
    if (e != null) {
        BackHandler { editing = null }
        EditScreen(e, sug, { vm.save(it); editing = null }, { vm.delete(it); editing = null }, { editing = null })
        return
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("物料库存") }) },
        floatingActionButton = {
            ExtendedFloatingActionButton(onClick = {
                val f = File(File(ctx.filesDir, "photos").apply { mkdirs() }, "${System.currentTimeMillis()}.jpg")
                pending = f
                cam.launch(FileProvider.getUriForFile(ctx, "${ctx.packageName}.fp", f))
            }) { Text("拍照入库") }
        }
    ) { pad ->
        Column(Modifier.padding(pad).padding(12.dp)) {
            OutlinedTextField(q, { vm.query.value = it }, label = { Text("搜索名称/分类/条码") }, modifier = Modifier.fillMaxWidth())
            LazyColumn {
                items(list, key = { it.id }) { i ->
                    ItemRow(i, { editing = i; sug = Suggestion() }) { d ->
                        vm.save(i.copy(quantity = (i.quantity + d).coerceAtLeast(0)))
                    }
                }
            }
        }
    }
}

@Composable
fun ItemRow(i: Item, onClick: () -> Unit, onQty: (Int) -> Unit) {
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            AsyncImage(File(i.photoPath), null, Modifier.size(56.dp), contentScale = ContentScale.Crop)
            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Text(i.name, style = MaterialTheme.typography.titleMedium)
                Text(i.category.ifEmpty { "未分类" }, style = MaterialTheme.typography.bodySmall)
            }
            TextButton({ onQty(-1) }) { Text("−") }
            Text("${i.quantity}")
            TextButton({ onQty(1) }) { Text("+") }
        }
    }
}

@Composable
fun EditScreen(item: Item, sug: Suggestion, onSave: (Item) -> Unit, onDelete: (Item) -> Unit, onBack: () -> Unit) {
    var name by remember { mutableStateOf(item.name) }
    var cat by remember { mutableStateOf(item.category) }
    var qty by remember { mutableStateOf(item.quantity.toString()) }
    var code by remember { mutableStateOf(item.barcode) }
    var note by remember { mutableStateOf(item.note) }
    val hints = sug.texts + sug.labels
    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        AsyncImage(File(item.photoPath), null, Modifier.fillMaxWidth().height(200.dp), contentScale = ContentScale.Fit)
        if (hints.isNotEmpty()) {
            Text("识别建议（点选填入名称）", style = MaterialTheme.typography.labelMedium)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(hints) { h -> AssistChip(onClick = { name = h }, label = { Text(h, maxLines = 1) }) }
            }
        }
        val m = Modifier.fillMaxWidth()
        OutlinedTextField(name, { name = it }, label = { Text("名称") }, modifier = m)
        OutlinedTextField(cat, { cat = it }, label = { Text("分类") }, modifier = m)
        OutlinedTextField(qty, { qty = it.filter(Char::isDigit) }, label = { Text("数量") }, modifier = m)
        OutlinedTextField(code, { code = it }, label = { Text("条码") }, modifier = m)
        OutlinedTextField(note, { note = it }, label = { Text("备注/位置") }, modifier = m)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(enabled = name.isNotBlank(), onClick = {
                onSave(item.copy(name = name.trim(), category = cat.trim(), quantity = qty.toIntOrNull() ?: 0, barcode = code.trim(), note = note.trim()))
            }) { Text("保存") }
            OutlinedButton(onBack) { Text("取消") }
            if (item.id != 0L) TextButton({ onDelete(item) }) { Text("删除") }
        }
    }
}
