@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, kotlinx.coroutines.ExperimentalCoroutinesApi::class)
package com.example.stock

import android.app.Application
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.room.Room
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

const val LOW = 2 // 数量 ≤ 此值时在列表中标红
const val XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"

class VM(app: Application) : AndroidViewModel(app) {
    val dao = Room.databaseBuilder(app, AppDb::class.java, "stock.db").addMigrations(MIGRATION_1_2).build().dao()
    val query = MutableStateFlow("")
    val items = query.flatMapLatest { dao.search(it) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val cats = dao.cats().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    fun save(i: Item) = viewModelScope.launch { dao.upsert(i) }
    fun delete(i: Item) = viewModelScope.launch { dao.delete(i) }

    /** 更新使用量：已匹配的物料按 BOM 数量×板数 扣减库存(最低扣到 0)，并补全库里缺的封装/型号。 */
    fun applyUsage(ms: List<Match>, boards: Int, done: (updated: Int, short: Int) -> Unit) = viewModelScope.launch {
        val byId = dao.all().associateBy { it.id }
        var upd = 0; var short = 0
        ms.filter { it.item != null }.groupBy { it.item!!.id }.forEach { (id, g) ->
            val cur = byId[id] ?: return@forEach
            val need = g.sumOf { it.row.qty } * boards
            if (cur.quantity < need) short++
            val r = g.first().row
            dao.upsert(cur.copy(
                quantity = (cur.quantity - need).coerceAtLeast(0),
                footprint = cur.footprint.ifBlank { r.footprint },
                partNo = cur.partNo.ifBlank { r.lcsc.ifBlank { r.mpn } }))
            upd++
        }
        done(upd, short)
    }

    /** 把库里没有的物料以数量 0 加入库。 */
    fun addMissing(ms: List<Match>, done: (Int) -> Unit) = viewModelScope.launch {
        val seen = HashSet<String>(); var n = 0
        ms.filter { it.item == null }.forEach { m ->
            val r = m.row
            if (seen.add("${norm(r.name)}|${norm(r.footprint)}|${r.lcsc}")) {
                dao.upsert(Item(name = r.name, category = guessCat(r), quantity = 0, barcode = "", note = "",
                    photoPath = "", footprint = r.footprint, partNo = r.lcsc.ifBlank { r.mpn }))
                n++
            }
        }
        done(n)
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { App() } }
    }
}

@Composable
fun App(vm: VM = viewModel()) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val list by vm.items.collectAsState()
    val cats by vm.cats.collectAsState()
    val q by vm.query.collectAsState()
    var catFilter by remember { mutableStateOf<String?>(null) }
    var editing by remember { mutableStateOf<Item?>(null) }
    var sug by remember { mutableStateOf(Suggestion()) }
    var pending by remember { mutableStateOf<File?>(null) }
    var busy by remember { mutableStateOf(false) }
    var bom by remember { mutableStateOf<List<BomRow>?>(null) }
    var libSnap by remember { mutableStateOf<List<Item>>(emptyList()) }

    val cam = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val f = pending ?: return@rememberLauncherForActivityResult
        if (!ok) { f.delete(); return@rememberLauncherForActivityResult }
        busy = true
        scope.launch {
            val s = runCatching { recognize(ctx, Uri.fromFile(f)) }.getOrDefault(Suggestion())
            val dup = if (s.barcode.isNotEmpty()) vm.dao.byBarcode(s.barcode) else null
            sug = s
            if (dup != null) Toast.makeText(ctx, "条码已存在，数量已+1", Toast.LENGTH_SHORT).show()
            editing = dup?.copy(quantity = dup.quantity + 1)
                ?: Item(name = "", category = "", quantity = 1, barcode = s.barcode, note = "", photoPath = f.absolutePath)
            busy = false
        }
    }
    fun shoot() {
        val f = File(File(ctx.filesDir, "photos").apply { mkdirs() }, "${System.currentTimeMillis()}.jpg")
        pending = f
        cam.launch(FileProvider.getUriForFile(ctx, "${ctx.packageName}.fp", f))
    }

    val importPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            val parsed = runCatching {
                withContext(Dispatchers.IO) { ctx.contentResolver.openInputStream(uri)!!.use { parseBom(Xlsx.read(it)) } }
            }.getOrNull()
            if (parsed.isNullOrEmpty()) {
                Toast.makeText(ctx, "没有识别到 BOM 数据：请选择 .xlsx 文件，且包含 Quantity、Comment、Footprint 等列", Toast.LENGTH_LONG).show()
            } else { libSnap = vm.dao.all(); bom = parsed }
        }
    }
    val exportPicker = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument(XLSX)) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            val ok = runCatching {
                val all = vm.dao.all()
                withContext(Dispatchers.IO) { ctx.contentResolver.openOutputStream(uri)!!.use { Xlsx.write(it, exportRows(all), EXPORT_WIDTHS) } }
            }.isSuccess
            Toast.makeText(ctx, if (ok) "已导出库存表" else "导出失败", Toast.LENGTH_SHORT).show()
        }
    }

    val e = editing
    if (e != null) {
        BackHandler { editing = null }
        EditScreen(e, sug, cats,
            onSave = { it, again -> vm.save(it); editing = null; if (again) shoot() },
            onDelete = { vm.delete(it); editing = null },
            onBack = { editing = null })
        return
    }
    val b = bom
    if (b != null) {
        BackHandler { bom = null }
        ImportScreen(b, libSnap,
            onUsage = { ms, n ->
                vm.applyUsage(ms, n) { u, s ->
                    Toast.makeText(ctx, "已更新 $u 种物料库存" + if (s > 0) "，其中 $s 种库存不足(已扣到0)" else "", Toast.LENGTH_LONG).show()
                }
                bom = null
            },
            onAdd = { ms -> vm.addMissing(ms) { n -> Toast.makeText(ctx, "已添加 $n 种物料(数量0)", Toast.LENGTH_SHORT).show() }; bom = null },
            onClose = { bom = null })
        return
    }

    val shown = list.filter { catFilter == null || it.category == catFilter }
    Box(Modifier.fillMaxSize()) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("库存 ${shown.size}种/${shown.sumOf { it.quantity }}件") },
                    actions = {
                        TextButton({ importPicker.launch(arrayOf("*/*")) }) { Text("导入") }
                        TextButton({
                            exportPicker.launch("物料库存_" + SimpleDateFormat("yyyyMMdd", Locale.getDefault()).format(Date()) + ".xlsx")
                        }) { Text("导出") }
                    })
            },
            floatingActionButton = { ExtendedFloatingActionButton(onClick = { shoot() }) { Text("拍照入库") } }
        ) { pad ->
            Column(Modifier.padding(pad).padding(horizontal = 12.dp)) {
                OutlinedTextField(q, { vm.query.value = it }, label = { Text("搜索名称/分类/封装/型号/条码") },
                    singleLine = true, modifier = Modifier.fillMaxWidth())
                if (cats.isNotEmpty()) LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(vertical = 6.dp)) {
                    item { FilterChip(catFilter == null, { catFilter = null }, { Text("全部") }) }
                    items(cats) { c -> FilterChip(catFilter == c, { catFilter = if (catFilter == c) null else c }, { Text(c) }) }
                }
                if (shown.isEmpty()) Text("还没有物料：点右下角“拍照入库”，或右上角“导入”BOM 表", Modifier.padding(24.dp))
                LazyColumn(contentPadding = PaddingValues(bottom = 88.dp)) {
                    items(shown, key = { it.id }) { i ->
                        ItemRow(i, { editing = i; sug = Suggestion() }) { d ->
                            vm.save(i.copy(quantity = (i.quantity + d).coerceAtLeast(0)))
                        }
                    }
                }
            }
        }
        if (busy) Box(Modifier.fillMaxSize().background(Color(0x99000000)), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                CircularProgressIndicator()
                Spacer(Modifier.height(8.dp))
                Text("识别中…", color = Color.White)
            }
        }
    }
}

@Composable
fun ImportScreen(rows: List<BomRow>, lib: List<Item>, onUsage: (List<Match>, Int) -> Unit,
                 onAdd: (List<Match>) -> Unit, onClose: () -> Unit) {
    var usage by remember { mutableStateOf(false) }
    var boards by remember { mutableStateOf("1") }
    val n = (boards.toIntOrNull() ?: 1).coerceAtLeast(1)
    val ms = remember(rows, lib) { matchAll(rows, lib) }
    val stock = lib.associate { it.id to it.quantity }
    val need = ms.filter { it.item != null }.groupBy { it.item!!.id }.mapValues { e -> e.value.sumOf { it.row.qty } * n }
    val found = ms.count { it.item != null }
    val missing = ms.size - found
    val short = need.count { (id, q) -> (stock[id] ?: 0) < q }

    Scaffold(
        topBar = { TopAppBar(title = { Text("导入 BOM") }, navigationIcon = { TextButton(onClose) { Text("关闭") } }) },
        bottomBar = {
            Surface(tonalElevation = 3.dp) {
                Box(Modifier.fillMaxWidth().padding(12.dp)) {
                    if (usage) Button({ onUsage(ms, n) }, enabled = found > 0, modifier = Modifier.fillMaxWidth()) {
                        Text("确认扣减库存（$found 种已入库物料）")
                    } else Button({ onAdd(ms) }, enabled = missing > 0, modifier = Modifier.fillMaxWidth()) {
                        Text("把未入库的 $missing 种添加到库（数量0）")
                    }
                }
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad).padding(horizontal = 12.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(!usage, { usage = false }, { Text("匹配物料") })
                FilterChip(usage, { usage = true }, { Text("更新使用量") })
            }
            if (usage) OutlinedTextField(boards, { boards = it.filter(Char::isDigit) },
                label = { Text("做几块板（BOM 数量 × 板数）") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth().padding(top = 6.dp))
            Text("共 ${ms.size} 种：已入库 $found，未入库 $missing" + if (usage && short > 0) "，库存不足 $short" else "",
                style = MaterialTheme.typography.labelLarge, modifier = Modifier.padding(vertical = 8.dp))
            LazyColumn {
                items(ms) { m ->
                    val it0 = m.item
                    val low = it0 != null && (stock[it0.id] ?: 0) < (need[it0.id] ?: 0)
                    Card(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(m.row.name, style = MaterialTheme.typography.titleSmall, maxLines = 1)
                                Text(listOf(m.row.footprint, m.row.designator).filter { it.isNotBlank() }.joinToString(" · "),
                                    style = MaterialTheme.typography.bodySmall, maxLines = 1)
                            }
                            val txt = when {
                                it0 == null -> "未入库"
                                usage -> "用${m.row.qty * n} / 库存${it0.quantity}"
                                else -> "已入库 · 库存${it0.quantity}"
                            }
                            Text(txt, style = MaterialTheme.typography.bodySmall,
                                color = if (it0 == null || (usage && low)) MaterialTheme.colorScheme.error else Color.Unspecified)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ItemRow(i: Item, onClick: () -> Unit, onQty: (Int) -> Unit) {
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            if (i.photoPath.isNotBlank()) AsyncImage(File(i.photoPath), null, Modifier.size(56.dp), contentScale = ContentScale.Crop)
            else Box(Modifier.size(56.dp))
            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Text(i.name, style = MaterialTheme.typography.titleMedium, maxLines = 1)
                Text(listOf(i.category.ifEmpty { "未分类" }, i.footprint, i.note).filter { it.isNotBlank() }.joinToString(" · "),
                    style = MaterialTheme.typography.bodySmall, maxLines = 1)
            }
            TextButton({ onQty(-1) }) { Text("−") }
            Text("${i.quantity}", style = MaterialTheme.typography.titleMedium,
                color = if (i.quantity <= LOW) MaterialTheme.colorScheme.error else Color.Unspecified)
            TextButton({ onQty(1) }) { Text("+") }
        }
    }
}

@Composable
fun F(v: String, label: String, onChange: (String) -> Unit, onFocus: () -> Unit, last: Boolean = false) {
    OutlinedTextField(v, onChange, label = { Text(label) }, singleLine = true,
        modifier = Modifier.fillMaxWidth().onFocusChanged { if (it.isFocused) onFocus() },
        keyboardOptions = KeyboardOptions(imeAction = if (last) ImeAction.Done else ImeAction.Next))
}

@Composable
fun EditScreen(item: Item, sug: Suggestion, cats: List<String>,
               onSave: (Item, Boolean) -> Unit, onDelete: (Item) -> Unit, onBack: () -> Unit) {
    var name by remember { mutableStateOf(item.name) }
    var cat by remember { mutableStateOf(item.category) }
    var fp by remember { mutableStateOf(item.footprint) }
    var pn by remember { mutableStateOf(item.partNo) }
    var qty by remember { mutableStateOf(item.quantity.toString()) }
    var code by remember { mutableStateOf(item.barcode) }
    var note by remember { mutableStateOf(item.note) }
    var target by remember { mutableStateOf("名称") } // 识别结果将填入的字段，随光标自动切换
    var confirm by remember { mutableStateOf(false) }
    val hints = (sug.texts + sug.labels).distinct()

    fun fill(t: String) {
        when (target) {
            "名称" -> name = t
            "分类" -> cat = t
            "封装" -> fp = t
            "型号" -> pn = t
            "条码" -> code = t
            else -> note = if (note.isBlank()) t else "$note $t"
        }
    }
    fun build() = item.copy(name = name.trim(), category = cat.trim(), footprint = fp.trim(), partNo = pn.trim(),
        quantity = qty.toIntOrNull() ?: 0, barcode = code.trim(), note = note.trim())

    Scaffold(topBar = {
        TopAppBar(
            title = { Text(if (item.id == 0L) "新物料" else "编辑物料") },
            navigationIcon = { TextButton(onBack) { Text("取消") } },
            actions = { TextButton(onClick = { onSave(build(), false) }, enabled = name.isNotBlank()) { Text("保存") } })
    }) { pad ->
        Column(Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (item.photoPath.isNotBlank())
                AsyncImage(File(item.photoPath), null, Modifier.fillMaxWidth().height(160.dp), contentScale = ContentScale.Fit)
            if (hints.isNotEmpty()) {
                Text("点选识别结果，填入：", style = MaterialTheme.typography.labelMedium)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(listOf("名称", "分类", "封装", "型号", "条码", "备注")) { t ->
                        FilterChip(target == t, { target = t }, { Text(t) })
                    }
                }
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(hints) { h -> AssistChip(onClick = { fill(h) }, label = { Text(h, maxLines = 1) }) }
                }
            }
            F(name, "名称", { name = it }, { target = "名称" })
            F(cat, "分类", { cat = it }, { target = "分类" })
            if (cats.isNotEmpty()) LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(cats) { c -> AssistChip(onClick = { cat = c }, label = { Text(c) }) }
            }
            F(fp, "封装（如 C0603）", { fp = it }, { target = "封装" })
            F(pn, "型号/编号（如 C14663）", { pn = it }, { target = "型号" })
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton({ qty = ((qty.toIntOrNull() ?: 0) - 1).coerceAtLeast(0).toString() }) { Text("−") }
                OutlinedTextField(qty, { qty = it.filter(Char::isDigit) }, label = { Text("数量") }, singleLine = true,
                    modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next))
                OutlinedButton({ qty = ((qty.toIntOrNull() ?: 0) + 1).toString() }) { Text("+") }
            }
            F(code, "条码", { code = it }, { target = "条码" })
            F(note, "备注/位置", { note = it }, { target = "备注" }, last = true)
            if (item.id == 0L) Button(onClick = { onSave(build(), true) }, enabled = name.isNotBlank(),
                modifier = Modifier.fillMaxWidth()) { Text("保存并继续拍照") }
            if (item.id != 0L) TextButton({ confirm = true }) {
                Text("删除这件物料", color = MaterialTheme.colorScheme.error)
            }
        }
    }
    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false },
        title = { Text("确认删除？") }, text = { Text(item.name) },
        confirmButton = { TextButton({ onDelete(item) }) { Text("删除") } },
        dismissButton = { TextButton({ confirm = false }) { Text("取消") } })
}
