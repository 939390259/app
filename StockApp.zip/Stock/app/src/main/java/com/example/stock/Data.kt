package com.example.stock

import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

@Entity
data class Item(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String, val category: String, val quantity: Int,
    val barcode: String, val note: String, val photoPath: String,
    val createdAt: Long = System.currentTimeMillis(),
    @ColumnInfo(defaultValue = "''") val footprint: String = "",   // 封装
    @ColumnInfo(defaultValue = "''") val partNo: String = ""       // 型号/编号(如立创 C 编号)
)

@Dao
interface ItemDao {
    @Query("SELECT * FROM Item WHERE name LIKE '%'||:q||'%' OR category LIKE '%'||:q||'%' OR barcode LIKE '%'||:q||'%' OR footprint LIKE '%'||:q||'%' OR partNo LIKE '%'||:q||'%' ORDER BY createdAt DESC")
    fun search(q: String): Flow<List<Item>>
    @Query("SELECT * FROM Item") suspend fun all(): List<Item>
    @Query("SELECT DISTINCT category FROM Item WHERE category != '' ORDER BY category")
    fun cats(): Flow<List<String>>
    @Query("SELECT * FROM Item WHERE barcode = :b AND barcode != '' LIMIT 1")
    suspend fun byBarcode(b: String): Item?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(i: Item)
    @Delete suspend fun delete(i: Item)
}

@Database(entities = [Item::class], version = 2, exportSchema = false)
abstract class AppDb : RoomDatabase() { abstract fun dao(): ItemDao }

val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE Item ADD COLUMN footprint TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE Item ADD COLUMN partNo TEXT NOT NULL DEFAULT ''")
    }
}
