package com.example.stock

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity
data class Item(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String, val category: String, val quantity: Int,
    val barcode: String, val note: String, val photoPath: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Dao
interface ItemDao {
    @Query("SELECT * FROM Item WHERE name LIKE '%'||:q||'%' OR category LIKE '%'||:q||'%' OR barcode LIKE '%'||:q||'%' ORDER BY createdAt DESC")
    fun search(q: String): Flow<List<Item>>
    @Query("SELECT * FROM Item WHERE barcode = :b AND barcode != '' LIMIT 1")
    suspend fun byBarcode(b: String): Item?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(i: Item)
    @Delete suspend fun delete(i: Item)
}

@Database(entities = [Item::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() { abstract fun dao(): ItemDao }
