package com.example.stock

class BomRow(val qty: Int, val name: String, val footprint: String, val designator: String,
             val value: String, val mpn: String, val lcsc: String, val mfr: String)
class Match(val row: BomRow, val item: Item?)

val EXPORT_WIDTHS = listOf(6, 24, 28, 12, 22, 16, 10, 24)

/** 统一写法后再比较：忽略大小写、空格、Ω/ohm、µ/μ。 */
fun norm(s: String) = s.lowercase().replace("ω", "").replace("ohm", "")
    .replace("µ", "u").replace("μ", "u").replace(" ", "").replace("-", "").replace("_", "")

/** 识别立创EDA/嘉立创导出的 BOM：按表头找列(Quantity/Comment/Footprint/Designator/Supplier Part…)。 */
fun parseBom(rows: List<List<String>>): List<BomRow> {
    val hi = rows.indexOfFirst { r -> r.any { it.trim().lowercase() in setOf("quantity", "数量", "qty") } }
    if (hi < 0) return emptyList()
    val h = rows[hi].map { it.trim().lowercase() }
    fun col(vararg n: String) = h.indexOfFirst { it in n }
    val cQty = col("quantity", "数量", "qty")
    val cName = col("comment", "名称", "name")
    val cDes = col("designator", "位号")
    val cFp = col("footprint", "封装")
    val cVal = col("value", "参数", "值")
    val cMpn = col("manufacturer part", "厂家型号", "制造商型号")
    val cLcsc = col("supplier part", "供应商编号", "立创编号")
    val cMfr = col("manufacturer", "制造商", "厂家")
    fun g(r: List<String>, c: Int) = if (c in r.indices) r[c].trim() else ""
    return rows.drop(hi + 1).mapNotNull { r ->
        val q = g(r, cQty).toDoubleOrNull()?.toInt() ?: return@mapNotNull null
        if (q <= 0) return@mapNotNull null
        val name = g(r, cName).ifBlank { g(r, cVal) }.ifBlank { g(r, cMpn) }
        if (name.isBlank()) return@mapNotNull null
        BomRow(q, name, g(r, cFp), g(r, cDes), g(r, cVal), g(r, cMpn), g(r, cLcsc), g(r, cMfr))
    }
}

/** 匹配顺序：①型号/编号相同 ②名称+封装相同 ③名称相同且库里该物料未登记封装。 */
fun matchAll(rows: List<BomRow>, lib: List<Item>): List<Match> = rows.map { r ->
    val rn = norm(r.name); val rv = norm(r.value); val rf = norm(r.footprint)
    fun nameOk(i: Item) = norm(i.name).let { it == rn || (rv.isNotEmpty() && it == rv) }
    val byNo = lib.firstOrNull { it.partNo.isNotBlank() && (it.partNo.equals(r.lcsc, true) || it.partNo.equals(r.mpn, true)) }
    val exact = lib.firstOrNull { nameOk(it) && it.footprint.isNotBlank() && norm(it.footprint) == rf }
    val loose = lib.firstOrNull { nameOk(it) && it.footprint.isBlank() }
    Match(r, byNo ?: exact ?: loose)
}

/** 新增物料时按参数/位号猜分类，可在编辑页再改。 */
fun guessCat(r: BomRow): String {
    val n = r.name.trim()
    return when {
        Regex("^[\\d.]+\\s*[pnuµμm]?F$", RegexOption.IGNORE_CASE).containsMatchIn(n) -> "电容"
        Regex("[Ωω]$|ohm$", RegexOption.IGNORE_CASE).containsMatchIn(n) -> "电阻"
        Regex("^[\\d.]+\\s*[nuµμm]?H$", RegexOption.IGNORE_CASE).containsMatchIn(n) -> "电感"
        else -> when (Regex("^[A-Za-z]+").find(r.designator.trim())?.value?.uppercase()) {
            "C" -> "电容"
            "R" -> "电阻"
            "L" -> "电感"
            "D" -> "二极管"
            "LED" -> "LED"
            "Q" -> "晶体管/MOS"
            "U" -> "芯片"
            "X", "Y" -> "晶振"
            "CN", "J", "P" -> "连接器"
            "SCREW" -> "螺丝"
            "TP" -> "测试点"
            "F" -> "保险丝"
            "SW", "S" -> "开关"
            else -> ""
        }
    }
}

fun exportRows(items: List<Item>): List<List<Any?>> {
    val head = listOf<Any?>("序号", "名称", "封装", "分类", "型号/编号", "条码", "剩余数量", "备注")
    val body = items.sortedWith(compareBy({ it.category }, { it.name })).mapIndexed { i, x ->
        listOf<Any?>(i + 1, x.name, x.footprint, x.category, x.partNo, x.barcode, x.quantity, x.note)
    }
    val last = body.size + 1
    val out = ArrayList<List<Any?>>()
    out.add(head)
    out.addAll(body)
    out.add(listOf<Any?>("", "合计", "", "", "", "", Formula("SUM(G2:G$last)"), ""))
    return out
}
